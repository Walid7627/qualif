package com.sigma.repository;

import com.sigma.model.Qualif;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualifRepository extends JpaRepository<Qualif, Long> {

}
