package com.sigma.model;

public enum FournisseurType {
    TYPE_MAISON_MERE,
    TYPE_FILIALE,
    TYPE_SUCCURSALE
}
